File targetFolder = new File(basedir, "target")
assert !targetFolder.exists()
