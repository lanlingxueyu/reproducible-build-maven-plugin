package io.github.zlika.reproducible.options;

import java.io.Serializable;

/**
 * A MatchTextFile parameter
 * @author Administrator
 *
 */
@SuppressWarnings("all")
public class MatchTextFile implements Serializable
{
	/**
	 * matched a Line  Content
	 */
	private String matchedLineContent;
	
	/**
	 * matched Path
	 */
	private String matchedPath;

	/**
     * Method equals.
     * 
     * @param other
     * @return boolean
     */
    public boolean equals( Object other )
    {
        if ( this == other )
        {
            return true;
        }

        if ( !( other instanceof MatchTextFile ) )
        {
            return false;
        }

        MatchTextFile that = (MatchTextFile) other;
        boolean result = true;

        result = result && ( getMatchedLineContent() == null ? that.getMatchedLineContent() == null : getMatchedLineContent().equals( that.getMatchedLineContent() ) );
        result = result && ( getMatchedPath() == null ? that.getMatchedPath() == null : getMatchedPath().equals( that.getMatchedPath() ) );

        return result;
    } //-- boolean equals( Object )
    
    /**
     * Method hashCode.
     * 
     * @return int
     */
    public int hashCode()
    {
        int result = 17;

        result = 37 * result + ( matchedLineContent != null ? matchedLineContent.hashCode() : 0 );
        result = 37 * result + ( matchedPath != null ? matchedPath.hashCode() : 0 );

        return result;
    } //-- int hashCode()
    
    /**
     * Method toString.
     * 
     * @return String
     */
    public String toString()
    {
    	StringBuilder buf = new StringBuilder( 128 );
    	buf.append("{[matchTextFile]:");
    	buf.append("[matchedLineContent]='");
    	buf.append(this.matchedLineContent);
    	buf.append("'[matchedPath]='");
    	buf.append(this.matchedPath);
    	buf.append("']}");
		return buf.toString();
    }
    public String getMatchedLineContent() {
		return matchedLineContent;
	}

	public void setMatchedLineContent(String matchedLineContent) {
		this.matchedLineContent = matchedLineContent;
	}

	public String getMatchedPath() {
		return matchedPath;
	}

	public void setMatchedPath(String matchedPath) {
		this.matchedPath = matchedPath;
	}
}
