package io.github.zlika.reproducible.options;

import java.io.Serializable;

/**
 * A MatchTextFile parameter
 * @author Administrator
 *
 */
@SuppressWarnings("all")
public class ReplaceBinaryFile implements Serializable
{
	/**
	 * matched a Line  Content
	 */
	private String matchedPath;
	
	/**
	 * matched Path
	 */
	private String replaceFile;

	/**
     * Method equals.
     * 
     * @param other
     * @return boolean
     */
    public boolean equals( Object other )
    {
        if ( this == other )
        {
            return true;
        }

        if ( !( other instanceof ReplaceBinaryFile ) )
        {
            return false;
        }

        ReplaceBinaryFile that = (ReplaceBinaryFile) other;
        boolean result = true;

        result = result && ( getMatchedPath() == null ? that.getMatchedPath() == null : getMatchedPath().equals( that.getMatchedPath() ) );
        result = result && ( getReplaceFile() == null ? that.getReplaceFile() == null : getReplaceFile().equals( that.getReplaceFile() ) );

        return result;
    } //-- boolean equals( Object )
    
    /**
     * Method hashCode.
     * 
     * @return int
     */
    public int hashCode()
    {
        int result = 17;

        result = 37 * result + ( matchedPath != null ? matchedPath.hashCode() : 0 );
        result = 37 * result + ( replaceFile != null ? replaceFile.hashCode() : 0 );

        return result;
    } //-- int hashCode()
    
    /**
     * Method toString.
     * 
     * @return String
     */
    public String toString()
    {
    	StringBuilder buf = new StringBuilder( 128 );
    	buf.append("{[ReplaceBinaryFile]:");
    	buf.append("[matchedPath]='");
    	buf.append(this.matchedPath);
    	buf.append("'[replaceFile]='");
    	buf.append(this.replaceFile);
    	buf.append("']}");
		return buf.toString();
    }

	public String getMatchedPath() {
		return matchedPath;
	}

	public void setMatchedPath(String matchedPath) {
		this.matchedPath = matchedPath;
	}

	public String getReplaceFile() {
		return replaceFile;
	}

	public void setReplaceFile(String replaceFile) {
		this.replaceFile = replaceFile;
	}

	

	
   
    
}
